import torch
import torchvision.transforms as transforms
from torchvision.datasets import ImageFolder

root_dir = './USB_MD/train'
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])
dataset = ImageFolder(root=root_dir, transform=transform)

loader = torch.utils.data.DataLoader(dataset, batch_size=len(dataset))
data = next(iter(loader))
images = data[0]

mean = torch.mean(images, dim=(0,2,3))
std = torch.std(images, dim=(0,2,3))

print("mean:", mean)
print("std:", std)