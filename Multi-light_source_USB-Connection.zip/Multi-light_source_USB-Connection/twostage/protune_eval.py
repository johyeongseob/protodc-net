import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ViewDataset import ViewDataset
import torch, os
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import torchvision.transforms.functional as F
import torch.nn as nn
from ProTunedSqueezeNet import ProTunedSqueezeNet
from util import set_seed


set_seed(seed=42)
device = torch.device("cuda:2" if torch.cuda.is_available() else "cpu")

# Define dataSet, dataLoader
num_cores = os.cpu_count()
num_workers = max(1, num_cores // 2)  # 코어 수의 50%로 설정

test_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/test'
test_dataset = ViewDataset(root_dir=test_dir, train_is=False)
print("전체 테스트 이미지 개수:", len(test_dataset))
test_loader = DataLoader(test_dataset, batch_size=2 ** 7, shuffle=False, num_workers=num_workers)

model = ProTunedSqueezeNet().to(device)
model.load_state_dict(torch.load("./twostage/protune_batch128.pth", map_location=device))
model.eval()

test_correct, test_total = 0, 0
with torch.no_grad():
    for images, labels in test_loader:
        images = images.to(device)
        labels = labels.to(device)
        
        outputs = model(images)
        preds = outputs.argmax(dim=-1)
        test_correct += (preds == labels).sum().item()
        test_total += labels.numel()

    test_acc = test_correct / test_total * 100
    print(f"Test Acc: {test_acc:.2f}%")
