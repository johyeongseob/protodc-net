import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from DefectDataset import DefectDataset
import torch, os
from torch.utils.data import DataLoader
import torch.nn.functional as F
import torch.nn as nn
from ProTunedSqueezeNet import ProTunedSqueezeNet
from DefectSqueezeNet import DefectSqueezeNet, MultiviewClassifier
from util import set_seed
from sklearn.metrics import confusion_matrix


set_seed(seed=42)
device = torch.device("cuda:2" if torch.cuda.is_available() else "cpu")

# Define dataSet, dataLoader
num_cores = os.cpu_count()
num_workers = max(1, num_cores // 2)  # 코어 수의 50%로 설정

train_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/train'
valid_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/valid'
train_dataset = DefectDataset(root_dir=train_dir)
print("전체 훈련 샘플 개수:", len(train_dataset))
valid_dataset = DefectDataset(root_dir=valid_dir)
print("전체 검증 샘플 개수:", len(valid_dataset))
train_loader = DataLoader(train_dataset, batch_size=2 ** 5, shuffle=True, num_workers=num_workers)
valid_loader = DataLoader(valid_dataset, batch_size=2 ** 5, shuffle=False, num_workers=num_workers)

squeezenet = DefectSqueezeNet().to(device)
squeezenet.load_state_dict(torch.load("./twostage/protune_batch32.pth", map_location=device))

model = MultiviewClassifier(squeezenet).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(
    filter(lambda p: p.requires_grad, model.parameters()), 
    lr=1e-4, 
    weight_decay=1e-4
)

total_params = sum(p.numel() for p in model.parameters())
print(f"전체 파라미터 개수: {total_params}")  # 1760666

num_epochs = 100
best_acc = 0.0

for epoch in range(num_epochs):
    model.train()
    train_loss = 0
    train_outputs, train_targets = [], []

    for images, labels in train_loader:
        images = images.to(device)         # [B, 4, C, H, W]
        labels = labels.to(device)         # [B]
        
        optimizer.zero_grad()
        losses = torch.tensor(0.0, device=device, requires_grad=True)

        logits, fused_logit = model(images)

        for logit in logits:
            losses = losses + criterion(logit, labels)
        losses = losses + criterion(fused_logit, labels)
        losses.backward()
        optimizer.step()

        _, pred = torch.max(fused_logit, 1)
        train_outputs.extend(pred.cpu().numpy())
        train_targets.extend(labels.cpu().numpy())

        train_loss += losses.item()
        
    if epoch % 10 == 0 and epoch != 0:
        train_matrix = confusion_matrix(train_targets, train_outputs)
        print(f"Epoch {epoch+1}, Loss: {train_loss: .4f}, Confusion matrix: \n{train_matrix}")
        # print(f"Epoch {epoch+1}, Loss: {train_loss: .4f}, Weight: {weight_path}, Confusion matrix: \n{train_matrix}")

    model.eval()
    valid_correct = 0
    valid_total = 0
    with torch.no_grad():
        for images, labels in valid_loader:
            images = images.to(device)
            labels = labels.to(device)

            _, fused_logit = model(images)

            preds = fused_logit.argmax(dim=-1)
            valid_correct += (preds == labels).sum().item()
            valid_total += labels.numel()

    valid_acc = valid_correct / valid_total * 100
    print(f"Valid Acc: {valid_acc:.2f}%")
    if valid_acc > best_acc:
        best_acc = valid_acc
        torch.save(model.state_dict(), "./twostage/defect.pth")
        print(f"✅ Best model saved at epoch {epoch+1} with acc {valid_acc:.2f}%")
    print("-" * 50)

    