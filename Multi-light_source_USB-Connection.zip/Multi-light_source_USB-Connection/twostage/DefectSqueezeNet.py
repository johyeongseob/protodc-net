import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F
from model import SENet

class SEBlock(nn.Module):
    def __init__(self, channels, reduction=16):
        super(SEBlock, self).__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, channels // reduction, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // reduction, channels, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        weight = self.fc(self.pool(x))
        return x * weight

# PromptBlock with 1x1 -> 5x5 (depthwise) -> 1x1 + SE
class PromptBlock(nn.Module):
    def __init__(self, in_channels):
        super(PromptBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.dwconv = nn.Conv2d(in_channels, in_channels, kernel_size=5, padding=2, groups=in_channels)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.se = SEBlock(in_channels)

    def forward(self, x):
        out = self.conv1(x)
        out = self.dwconv(out)
        out = self.conv2(out)
        out = self.se(out)
        return out
        

class DefectSqueezeNet(nn.Module):
    def __init__(self, beta=1.0, num_classes=4):
        super(DefectSqueezeNet, self).__init__()
        self.beta = beta

        # Load pretrained SqueezeNet
        base = models.squeezenet1_0(weights=models.SqueezeNet1_0_Weights.DEFAULT)
        for param in base.parameters():
            param.requires_grad = True

        # 🔥 Divide into 3 stages (or more if needed)
        self.stage1 = nn.Sequential(*base.features[0:4])   # conv1 + relu + maxpool + fire2
        self.stage2 = nn.Sequential(*base.features[4:7])   # fire3 + maxpool + fire4
        self.stage3 = nn.Sequential(*base.features[7:])    # fire5~fire9 + dropout + final conv

        # 🔥 Prompt Blocks after each stage
        self.prompt1 = PromptBlock(in_channels=128)   # fire2 output
        self.prompt2 = PromptBlock(in_channels=256)  # fire4 output
        self.prompt3 = PromptBlock(in_channels=512)  # final conv output

        # Classification head
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=512, out_channels=num_classes, kernel_size=1),
            nn.ReLU(),
        )
    
    def forward_features(self, x):
        # Stage 1
        x1 = self.stage1(x)
        x1_prompted = x1 - self.beta * self.prompt1(x1)

        # Stage 2
        x2 = self.stage2(x1_prompted)
        x2_prompted = x2 - self.beta * self.prompt2(x2)

        # Stage 3
        x3 = self.stage3(x2_prompted)
        x3_prompted = x3 - self.beta * self.prompt3(x3)
        return x3_prompted

    def forward(self, x):
        features = self.forward_features(x)

        # Classification
        out = self.conv(out)
        return F.adaptive_avg_pool2d(out, output_size=(1, 1)).view(out.size(0), -1)


class MultiviewClassifier(nn.Module):
    def __init__(self, squeezenet_model, num_classes=5):
        super().__init__()
        self.squeezenet = squeezenet_model
        self.senet = SENet(c=512)
        self.conv10 = nn.Sequential(
                    nn.Conv2d(in_channels=512, out_channels=num_classes, kernel_size=1),
                    nn.ReLU()
                )
        self.fused_senet = SENet(c=num_classes*4)
        self.fusion_conv = nn.Sequential(
            nn.Conv2d(in_channels=num_classes*4, out_channels=num_classes, kernel_size=3, padding=1),
        )

    def forward(self, images):
        """
        images: [B, 4, 3, 224, 224] (Batch, Views, Channels, Height, Width)
        """
        B, V, C, H, W = images.size()  # B: Batch, V: Views
        assert V == 4, "This model is designed for 4 views only."

        features, logits = [], []
        for v in range(V):
            feature = self.squeezenet.forward_features(images[:, v])
            feature = self.conv10(self.senet(feature))        # [B, 5, H', W']
            features.append(feature)
            logit = F.adaptive_avg_pool2d(feature, (1, 1)).view(feature.size(0), -1) 
            logits.append(logit)

        fused_features = torch.cat(features, dim=1)  # [B, 5*4, H', W']
        fused_features = self.fused_senet(fused_features)  # [B, 5*4, H', W']
        fused_features = self.fusion_conv(fused_features)  # [B, 5, H', W']
        fused_logit = F.adaptive_avg_pool2d(fused_features, (1,1)).view(B, -1)  # [B, 5]
        return logits, fused_logit