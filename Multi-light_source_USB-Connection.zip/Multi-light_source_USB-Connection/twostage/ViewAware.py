import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import torch, copy
import torch.nn as nn
import torch.nn.functional as F
from model import SqueezeNet, SENet, Fire
import numpy as np


class ViewAwareLayer(nn.Module):
    def __init__(self):
        super().__init__()
        self.fire1 = Fire(inplanes=512, squeeze_planes=16, expand1x1_planes=32, expand3x3_planes=32)
        self.fire2 = Fire(inplanes=64, squeeze_planes=8, expand1x1_planes=2, expand3x3_planes=2)
        self.senet = SENet(c=4)

    def forward(self, x):
        x = self.fire1(x)  # [B, 512, 12, 12] → [B, 64, 12, 12]
        x = self.fire2(x)  # [B, 64, 12, 12]  → [B, 4, 12, 12]
        x = self.senet(x)
        return F.adaptive_avg_pool2d(x, output_size=1).view(x.size(0), -1)  # [B, 4]


class ViewAwareCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.squeezenet = SqueezeNet()
        for param in self.squeezenet.parameters():
            param.requires_grad = False

        self.view_prompts = nn.ParameterList([nn.Parameter(torch.randn(512, 13, 13)) for _ in range(4)])
        self.view_layers = nn.ModuleList([ViewAwareLayer() for _ in range(4)])

    def forward(self, images):
        """
        images: [B, 4, 3, H, W]
        returns: list of view_features [v1, v2, ..., v4] each of shape [B, 512, 13, 13]
        """
        B, V, C, H, W = images.size()
        outputs = []
        for v in range(V):
            feature = self.squeezenet(images[:, v])                 # [B, 512, 13, 13]
            prompt = self.view_prompts[v].unsqueeze(0)              # [1, 512, 13, 13]
            prompt = prompt.expand(B, -1, -1, -1)                   # [B, 512, 13, 13]
            feature = feature + prompt                              # [B, 512, 13, 13]
            output = self.view_layers[v](feature)                   # [B, 4]
            outputs.append(output.unsqueeze(1))
        
        return torch.cat(outputs, dim=1)  # [B, 4, 4]


if __name__ == '__main__':
    # x = torch.rand(1, 4, 3, 200, 200)
    # labels = torch.Tensor([0])
    # Classifier = ViewAware()

    # out = Classifier(x)
    # print(f"out: {out[0].shape}")

    model = ViewAwareLayer()
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable parameters: {trainable_params:,}")