import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ViewDataset import ViewDataset
import torch, os
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import torchvision.transforms.functional as F
import torch.nn as nn
from ProTunedSqueezeNet import ProTunedSqueezeNet
from util import set_seed


set_seed(seed=42)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# Define dataSet, dataLoader
num_cores = os.cpu_count()
num_workers = max(1, num_cores // 2)  # 코어 수의 50%로 설정

train_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/train'
valid_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/valid'
train_dataset = ViewDataset(root_dir=train_dir, train_is=True)
print("전체 훈련 이미지 개수:", len(train_dataset))
valid_dataset = ViewDataset(root_dir=valid_dir, train_is=False)
print("전체 검증 이미지 개수:", len(valid_dataset))
train_loader = DataLoader(train_dataset, batch_size=2 ** 5, shuffle=False, num_workers=num_workers)
valid_loader = DataLoader(valid_dataset, batch_size=2 ** 5, shuffle=False, num_workers=num_workers)

model = ProTunedSqueezeNet().to(device)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(
    filter(lambda p: p.requires_grad, model.parameters()), 
    lr=1e-4, 
    weight_decay=1e-4
)
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"훈련 가능한 파라미터 개수: {trainable_params}")  # 759228

num_epochs = 50
best_acc = 0.0

for epoch in range(num_epochs):
    model.train()
    train_loss = 0
    for images, labels in train_loader:
        images = images.to(device)         # [B, 3, H, W]
        labels = labels.to(device)         # [B] — view별 GT (ex: 0, 1, 2, 3)
        
        optimizer.zero_grad()
        outputs = model(images)            # [B, 4]
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()

    print(f"Epoch: {epoch+1}\nTrain Loss: {train_loss:.4f}")

    model.eval()
    valid_correct, valid_total = 0, 0
    with torch.no_grad():
        for images, labels in valid_loader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)

            preds = outputs.argmax(dim=-1)
            valid_correct += (preds == labels).sum().item()
            valid_total += labels.numel()

    valid_acc = valid_correct / valid_total * 100
    print(f"Valid Acc: {valid_acc:.2f}%")

    if valid_acc > best_acc:
        best_acc = valid_acc
        torch.save(model.state_dict(), "./twostage/weights/protune_batch32.pth")
        print(f"✅ Best model saved at epoch {epoch+1} with acc {valid_acc:.2f}%")
    print("-" * 50)

    