import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.functional as F


class SEBlock(nn.Module):
    def __init__(self, channels, reduction=16):
        super(SEBlock, self).__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, channels // reduction, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // reduction, channels, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        weight = self.fc(self.pool(x))
        return x * weight

# PromptBlock with 1x1 -> 5x5 (depthwise) -> 1x1 + SE
class PromptBlock(nn.Module):
    def __init__(self, in_channels):
        super(PromptBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.dwconv = nn.Conv2d(in_channels, in_channels, kernel_size=5, padding=2, groups=in_channels)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.se = SEBlock(in_channels)

    def forward(self, x):
        out = self.conv1(x)
        out = self.dwconv(out)
        out = self.conv2(out)
        out = self.se(out)
        return out

# Pro-tuned SqueezeNet
class ProTunedSqueezeNet(nn.Module):
    def __init__(self, beta=1.0, num_classes=4):
        super(ProTunedSqueezeNet, self).__init__()
        self.beta = beta

        # Load pretrained SqueezeNet
        base = models.squeezenet1_0(weights=models.SqueezeNet1_0_Weights.DEFAULT)
        for param in base.parameters():
            param.requires_grad = False  # Freeze backbone

        # ❄️ Divide into 3 stages (or more if needed)
        self.stage1 = nn.Sequential(*base.features[0:4])    # conv1 ~ fire2
        self.stage2 = nn.Sequential(*base.features[4:7])    # fire3 ~ fire4
        self.stage3 = nn.Sequential(*base.features[7:9])    # fire5 ~ fire6
        self.stage4 = nn.Sequential(*base.features[9:])     # fire7 ~ fire9

        # 🔥 Prompt Blocks after each stage
        self.prompt1 = PromptBlock(in_channels=128)   
        self.prompt2 = PromptBlock(in_channels=256)
        self.prompt3 = PromptBlock(in_channels=384)

        # Classification head
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels=512, out_channels=num_classes, kernel_size=1),
            nn.ReLU(),
        )
    
    def forward_features(self, x):
        # Stage 1
        x1 = self.stage1(x)
        x1_prompted = x1 + self.beta * self.prompt1(x1)

        # Stage 2
        x2 = self.stage2(x1_prompted)
        x2_prompted = x2 + self.beta * self.prompt2(x2)

        # Stage 3
        x3 = self.stage3(x2_prompted)
        x3_prompted = x3 + self.beta * self.prompt3(x3)

        return self.stage4(x3_prompted)

    def forward(self, x):
        features = self.forward_features(x)

        # Classification
        out = self.conv(features)
        logit = F.adaptive_avg_pool2d(out, output_size=(1, 1)).view(out.size(0), -1)
        return logit


if __name__ =='__main__':
    base = models.squeezenet1_0(weights=models.SqueezeNet1_0_Weights.DEFAULT)
    print(base.features)

