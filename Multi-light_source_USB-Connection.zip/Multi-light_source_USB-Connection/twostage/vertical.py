import os
from PIL import Image

folder1 = './twostage/test'
folder2 = './twostage/cam_prompt3/concat'
save_dir = './twostage/prompt3_merged_vertical'
os.makedirs(save_dir, exist_ok=True)

# folder2에는 "cam_"으로 시작하는 파일이 있다고 가정
files1 = [f for f in os.listdir(folder1) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
files2 = [f for f in os.listdir(folder2) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]

# 이름 매칭을 위해 cam_ 접두사 제거
files2_dict = {f.replace('cam_', ''): f for f in files2}

for f1 in files1:
    if f1 in files2_dict:
        path1 = os.path.join(folder1, f1)
        path2 = os.path.join(folder2, files2_dict[f1])

        img1 = Image.open(path1)
        img2 = Image.open(path2)

        # 이미지 크기 통일 (가로는 최대값, 세로는 합)
        max_width = max(img1.width, img2.width)
        total_height = img1.height + img2.height

        new_img = Image.new('RGB', (max_width, total_height))
        new_img.paste(img1, (0, 0))
        new_img.paste(img2, (0, img1.height))

        save_path = os.path.join(save_dir, f1)
        new_img.save(save_path)
        print(f"✅ 저장됨: {save_path}")
    else:
        print(f"❌ 매칭 없음: {f1}")
