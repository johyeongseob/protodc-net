import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from DefectDataset import DefectDataset
import torch, os
from torch.utils.data import DataLoader
import torch.nn.functional as F
import torch.nn as nn
from ProTunedSqueezeNet import ProTunedSqueezeNet
from DefectSqueezeNet import DefectSqueezeNet, MultiviewClassifier
from util import set_seed
from sklearn.metrics import confusion_matrix
from util import calculate_accuracies


set_seed(seed=42)
device = torch.device("cuda:2" if torch.cuda.is_available() else "cpu")

# Define dataSet, dataLoader
num_cores = os.cpu_count()
num_workers = max(1, num_cores // 2)  # 코어 수의 50%로 설정

test_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/test'
test_dataset = DefectDataset(root_dir=test_dir)
print("전체 훈련 샘플 개수:", len(test_dataset))
test_loader = DataLoader(test_dataset, batch_size=2 ** 5, shuffle=True, num_workers=num_workers)

squeezenet = DefectSqueezeNet().to(device)
squeezenet.load_state_dict(torch.load("./twostage/protune_batch32.pth", map_location=device))

model = MultiviewClassifier(squeezenet).to(device)
model.load_state_dict(torch.load("./twostage/defect.pth"))

test_correct, test_total = 0, 0
test_outputs, test_targets = [], []
with torch.no_grad():
    for images, labels in test_loader:
        images = images.to(device)
        labels = labels.to(device)

        _, fused_logit = model(images)

        preds = fused_logit.argmax(dim=-1)
        test_outputs.extend(preds.cpu().numpy())
        test_targets.extend(labels.cpu().numpy())
        test_correct += (preds == labels).sum().item()
        test_total += labels.numel()

    test_acc = test_correct / test_total * 100
    calculate_accuracies(confusion_matrix(test_targets, test_outputs))
