import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import torch
from os.path import basename, splitext
import torch.nn.functional as F
import matplotlib.pyplot as plt
from ViewDataset import ViewDataset
from torch.utils.data import DataLoader
import torch.nn as nn
from ProTunedSqueezeNet import ProTunedSqueezeNet
from util import set_seed


set_seed(seed=42)

def gradcam_conv(model, image_tensor, target_class):
    model.eval()
    gradients = []
    activations = []

    def save_activation(module, input, output):
        activations.append(output)

    def save_gradient(module, grad_input, grad_output):
        gradients.append(grad_output[0])

    # 🔧 conv에 hook 등록
    h1 = model.conv.register_forward_hook(save_activation)
    h2 = model.conv.register_backward_hook(save_gradient)

    # 🔄 forward & backward
    output = model(image_tensor)  # shape: [B, num_classes]
    class_score = output[:, target_class]
    model.zero_grad()
    class_score.backward()

    # ❌ hook 제거
    h1.remove()
    h2.remove()

    # 📊 Grad-CAM 계산
    grad = gradients[0]           # [B, C, H, W]
    act = activations[0]         # [B, C, H, W]
    weights = grad.mean(dim=(2, 3), keepdim=True)  # GAP
    cam = (weights * act).sum(dim=1, keepdim=True)  # weighted sum
    cam = F.relu(cam)
    cam = F.interpolate(cam, size=image_tensor.shape[2:], mode='bilinear', align_corners=False)
    cam = cam / (cam.max() + 1e-6)

    return cam  # [B, 1, H, W]

def gradcam_prompt3(model, image_tensor, target_class):
    model.eval()
    gradients = []
    activations = []

    def save_activation(module, input, output):
        activations.append(output)

    def save_gradient(module, grad_input, grad_output):
        gradients.append(grad_output[0])

    # hook 등록 (prompt3의 출력에 대해)
    h1 = model.prompt3.register_forward_hook(save_activation)
    h2 = model.prompt3.register_backward_hook(save_gradient)

    # forward
    output = model(image_tensor)  # shape: [B, num_classes]
    class_score = output[:, target_class]  # target logit
    model.zero_grad()
    class_score.backward()

    # hook 제거
    h1.remove()
    h2.remove()

    # Grad-CAM 계산
    grad = gradients[0]           # [B, C, H, W]
    act = activations[0]         # [B, C, H, W]
    weights = grad.mean(dim=(2, 3), keepdim=True)  # GAP
    cam = (weights * act).sum(dim=1, keepdim=True)  # weighted sum
    cam = F.relu(cam)
    cam = F.interpolate(cam, size=image_tensor.shape[2:], mode='bilinear', align_corners=False)
    cam = cam / (cam.max() + 1e-6)

    return cam  # shape: [B, 1, H, W]

def save_cam_on_image(img_tensor, cam, save_path="./twostage/cam_output.png"):
    img = img_tensor.squeeze().permute(1, 2, 0).detach().cpu().numpy()
    img = (img - img.min()) / (img.max() - img.min())  # normalize

    cam_img = cam.squeeze().detach().cpu().numpy()

    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    plt.imshow(img)
    plt.imshow(cam_img, cmap='jet', alpha=0.5)
    plt.axis('off')
    plt.title("Grad-CAM on classifier")
    plt.savefig(save_path, bbox_inches='tight', pad_inches=0.1)
    plt.close()


# _________________________________________________________________________________

set_seed(seed=42)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# Define dataSet, dataLoader
num_cores = os.cpu_count()
num_workers = max(1, num_cores // 2)  # 코어 수의 50%로 설정

test_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/test'
test_dataset = ViewDataset(root_dir=test_dir, train_is=False)
print("전체 테스트 이미지 개수:", len(test_dataset))
test_loader = DataLoader(test_dataset, batch_size=2 ** 5, shuffle=False, num_workers=num_workers)

model = ProTunedSqueezeNet().to(device)
model.load_state_dict(torch.load("./twostage/weights/protune_batch128.pth", map_location=device))
model.eval()

for batch_idx, (images, labels) in enumerate(test_loader):
    images = images.to(device)
    labels = labels.to(device)

    for i in range(images.size(0)):
        dataset_idx = batch_idx * test_loader.batch_size + i
        image_path = test_dataset.data[dataset_idx][0]  # ← 여기!
        base_name = splitext(basename(image_path))[0]

        image = images[i].unsqueeze(0)  # (C, H, W) → (1, C, H, W)
        label = labels[i]
        image_tensor = image.clone().detach().requires_grad_(True)

        # Grad-CAM 실행
        target_class = int(label)  # 또는 예측 결과로 변경 가능
        cam = gradcam_conv(model, image_tensor, target_class)

        # 저장 경로 (배치 번호와 인덱스 포함해 고유하게 저장)
        save_path = f"./twostage/cam_conv/cam_{base_name}.png"
        save_cam_on_image(image_tensor, cam, save_path=save_path)

    print(f"batch: {batch_idx+1} / {int(len(test_dataset)/(2 ** 5)) + 1}")
    
