import os
import shutil

src_dir = './twostage/test/Scratch'  # 이미지가 저장된 경로
views = ['_Down_', '_Left_', '_Right_', '_Upper_']

# 폴더명 생성용 함수: view를 공통 토큰으로 치환
def get_common_key(filename):
    if not filename.endswith(".bmp"):
        return None
    name = filename[:-4]  # .png 제거
    for view in views:
        if view in name:
            return name.replace(view, '_')  # 뷰 단어 제거
    return None

# 이미지 파일 순회
for fname in os.listdir(src_dir):
    common_key = get_common_key(fname)
    if common_key:
        dst_folder = os.path.join(src_dir, common_key)
        os.makedirs(dst_folder, exist_ok=True)

        src_path = os.path.join(src_dir, fname)
        dst_path = os.path.join(dst_folder, fname)

        shutil.move(src_path, dst_path)
