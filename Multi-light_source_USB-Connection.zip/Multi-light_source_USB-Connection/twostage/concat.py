import os
from PIL import Image

root_dir = './twostage/test/Scratch'  # 최상위 폴더
save_root = os.path.join(root_dir, 'concat')
os.makedirs(save_root, exist_ok=True)  # concat 폴더 없으면 생성

# 하위 폴더들 순회
for folder_name in os.listdir(root_dir):
    folder_path = os.path.join(root_dir, folder_name)
    if not os.path.isdir(folder_path) or folder_name == 'concat':
        continue

    # 해당 폴더의 이미지 목록 정렬
    image_files = sorted([
        f for f in os.listdir(folder_path)
        if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))
    ])

    # 이미지가 4개 이상일 때만 처리
    if len(image_files) < 4:
        print(f"⚠️ {folder_name}: 이미지 4개 미만, 생략")
        continue

    # 이미지 4장 불러오기
    imgs = [Image.open(os.path.join(folder_path, fname)) for fname in image_files[:4]]

    # 가로로 이어붙이기
    widths, heights = zip(*(img.size for img in imgs))
    total_width = sum(widths)
    max_height = max(heights)

    new_img = Image.new('RGB', (total_width, max_height))
    x_offset = 0
    for img in imgs:
        new_img.paste(img, (x_offset, 0))
        x_offset += img.width

    # 저장 경로 지정
    save_name = folder_name + '_concat.png'
    save_path = os.path.join(save_root, save_name)
    new_img.save(save_path)
