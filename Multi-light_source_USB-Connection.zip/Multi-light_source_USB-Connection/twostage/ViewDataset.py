import os, random
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.3702, 0.3702, 0.3702], std=[0.1960, 0.1960, 0.1960])
])


class ViewDataset(Dataset):
    def __init__(self, root_dir, train_is=True):
        self.root_dir = root_dir
        self.data = []
        if  train_is:
            self.classes = ['Normal']
        else:
            self.classes = ['BrightLine', 'Deformation', 'Dent', 'Scratch', 'Normal']
        self.views = ['Down', 'Upper', 'Left', 'Right']

        print(f"ViewAwareDataset({os.path.basename(self.root_dir)}): classes: {self.classes}, View: {self.views}.")

        for class_name in self.classes:
            single_view_dir = os.path.join(self.root_dir, class_name, self.views[0])
            file_names = sorted(os.listdir(single_view_dir))

            for file_name in file_names:
                for view_label, view in enumerate(self.views):
                    modified_file_name = file_name.replace("_Down_", f"_{view}_")
                    file_path = os.path.join(self.root_dir, class_name, view, modified_file_name)
                    assert os.path.exists(file_path)
                    self.data.append([file_path, view_label])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        path, label = self.data[idx]  # views: list of [path, view_label]
    
        # 이미지 로딩 및 변환
        images_tensor = transform(Image.open(path).convert("RGB"))
        return images_tensor, torch.tensor(label)


if __name__ == '__main__':
    train_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/train'
    train_dataset = ViewDataset(root_dir=train_dir)
    train_loader = DataLoader(train_dataset, batch_size=2 ** 5, shuffle=True)
