import torch
from MD_baseline.FOMI_baseline import FOMI
from MD_baseline.ETE_MV import ETE_MV
from MD_baseline.DECAF_MLR_MV import DECAF_MLR_MV
from ProtoDC_Net.ProtoDC_loss import EmbeddingInput
from MD_baseline.MHAF import MHAF_classifier


def get_model_info(model):
    total_params = sum(p.numel() for p in model.parameters())  # 전체 파라미터 수
    total_size_bytes = sum(p.numel() * p.element_size() for p in model.parameters())  # 전체 용량
    total_size_mb = total_size_bytes / (1024 ** 2)

    print(f"Total Parameters: {total_params:,}")
    print(f"Model Size (in MB): {total_size_mb:.2f} MB")

model = MHAF_classifier()
get_model_info(model)