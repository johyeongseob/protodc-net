import torch
print(torch.__version__)             # PyTorch 버전
print(torch.version.cuda)            # PyTorch가 사용하는 CUDA 런타임 버전
print(torch.cuda.is_available())     # GPU 사용 가능 여부
print(torch.cuda.get_device_name(0)) # GPU 이름
