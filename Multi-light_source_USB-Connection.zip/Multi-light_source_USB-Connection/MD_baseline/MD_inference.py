import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import torch
from torch.utils.data import DataLoader
from MD_DataLoader import MultiViewDataset
from DECAF_MLR_MV import DECAF_MLR_MV
from ETE_MV import ETE_MV
from FOMI import FOMI
from SN_MRF_CC_MV import SN_MRF_CC_MV
from MHAF import MHAF
from util import *
from sklearn.metrics import confusion_matrix
import random, time

SEED = 44
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# Define dataSet, dataLoader
test_dir = '/home/johs/Multi-light_source_USB-Connection/USB_MD/test'
test_dataset = MultiViewDataset(root_dir=test_dir)
test_loader = DataLoader(test_dataset, batch_size=2**5, shuffle=False)

weight_path = f'/home/johs/Multi-light_source_USB-Connection/weights/real_SN_MRF_CC_MV.pth'

# Set up model and tools
model = FOMI().cuda()
model.load_state_dict(torch.load(weight_path))
model.eval()

print(f"\nTest model model {model.__class__.__name__}, Weight path: {weight_path}\n")

preds, targets = [], []
total_time, total_samples = 0.0, 0

with torch.no_grad():
    for images, labels in test_loader:
        images = images.to(device)
        labels = labels.to(device)
        batch_size = labels.size(0)
        total_samples += batch_size

        torch.cuda.synchronize() if device.type == 'cuda' else None
        start = time.time()

        # _, fused_outputs = model(images)
        fused_outputs = model(images)

        torch.cuda.synchronize() if device.type == 'cuda' else None
        end = time.time()

        _, pred = torch.max(fused_outputs, 1)
        preds.extend(pred.cpu().numpy())
        targets.extend(labels.cpu().numpy())

        total_time += (end - start)

calculate_accuracies(confusion_matrix(targets, preds))

avg_time_per_sample = total_time / total_samples
throughput = total_samples / total_time

print(f"\n⏱️ Avg time per 4-view sample: {avg_time_per_sample:.6f} sec")
print(f"⚡ Throughput: {throughput:.2f} samples/sec\n")